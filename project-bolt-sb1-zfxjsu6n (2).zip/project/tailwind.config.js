/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        'deep-space': '#0A0E17',
        'starlight': '#E4E9F2',
        'spacex-red': '#FF3C28',
        'spacex-blue': '#0078D4',
        'success': '#10B981',
        'warning': '#F59E0B',
        'error': '#EF4444',
        'neutral': {
          '800': '#1F2937',
          '900': '#111827',
        }
      },
      animation: {
        'pulse-slow': 'pulse 4s cubic-bezier(0.4, 0, 0.6, 1) infinite',
      }
    },
  },
  plugins: [],
};