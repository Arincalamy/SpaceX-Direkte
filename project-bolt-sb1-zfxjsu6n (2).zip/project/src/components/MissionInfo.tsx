import React from 'react';
import { Rocket, Calendar, MapPin, Info } from 'lucide-react';

export const MissionInfo = () => {
  return (
    <section className="glass-panel p-6 mb-6">
      <h2 className="section-title">
        <Info className="mr-2 text-spacex-red" />
        Current Mission
      </h2>
      
      <div>
        <h3 className="text-xl font-bold mb-2">Starship SN20 Orbital Test Flight</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <MissionDetail 
            icon={<Rocket className="text-spacex-red" />}
            label="Vehicle"
            value="Starship SN20 / Super Heavy BN4"
          />
          <MissionDetail 
            icon={<Calendar className="text-spacex-red" />}
            label="Launch Date"
            value="May 20, 2025 • 15:00 UTC"
          />
          <MissionDetail 
            icon={<MapPin className="text-spacex-red" />}
            label="Launch Site"
            value="Starbase, Boca Chica, TX"
          />
        </div>
        
        <div className="space-y-4">
          <p className="text-starlight/90 leading-relaxed">
            SpaceX is targeting the first orbital flight test of Starship, the most powerful launch vehicle ever developed. 
            Following a successful orbital test, Starship will be a fully reusable transportation system designed to carry 
            both crew and cargo to Earth orbit, the Moon, Mars, and beyond.
          </p>
          
          <div className="bg-deep-space/50 p-4 rounded-lg border-l-2 border-spacex-red">
            <h4 className="font-bold text-white mb-1">Mission Objectives:</h4>
            <ul className="list-disc list-inside space-y-1 text-starlight/90">
              <li>Demonstrate successful stage separation</li>
              <li>Test heat shield performance during orbital re-entry</li>
              <li>Validate new landing methodology for Super Heavy booster</li>
              <li>Evaluate overall system performance in real flight conditions</li>
            </ul>
          </div>
          
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-success rounded-full"></div>
              <span className="text-sm">Systems Nominal</span>
            </div>
            <button className="button-secondary text-sm">
              Full Mission Details
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

interface MissionDetailProps {
  icon: React.ReactNode;
  label: string;
  value: string;
}

const MissionDetail: React.FC<MissionDetailProps> = ({ icon, label, value }) => (
  <div className="flex items-start">
    <div className="mt-1 mr-3">
      {icon}
    </div>
    <div>
      <p className="text-starlight/70 text-sm">{label}</p>
      <p className="font-medium">{value}</p>
    </div>
  </div>
);