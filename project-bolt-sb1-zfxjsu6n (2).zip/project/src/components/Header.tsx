import React, { useState } from 'react';
import { Menu, X, Rocket, Bell, Search } from 'lucide-react';
import { ArchiveModal } from './ArchiveModal';

export const Header = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [showArchive, setShowArchive] = useState(false);

  React.useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header 
      className={`sticky top-0 z-50 transition-all duration-300 ${
        isScrolled ? 'bg-deep-space/90 backdrop-blur-md shadow-lg' : 'bg-transparent'
      }`}
    >
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16 md:h-20">
          <div className="flex items-center">
            <div className="flex items-center flex-shrink-0">
              <Rocket className="h-8 w-8 text-spacex-red" />
              <span className="ml-2 text-xl font-bold">SpaceX Direkte</span>
            </div>
            <nav className="hidden md:ml-10 md:flex space-x-8">
              <a href="#" className="text-starlight hover:text-white transition-colors">Live</a>
              <a href="#" className="text-starlight hover:text-white transition-colors">Missions</a>
              <a href="#" className="text-starlight hover:text-white transition-colors">Schedule</a>
              <a href="#" className="text-starlight hover:text-white transition-colors">News</a>
              <button 
                onClick={() => setShowArchive(true)}
                className="text-starlight hover:text-white transition-colors"
              >
                Archive
              </button>
            </nav>
          </div>
          
          <div className="hidden md:flex items-center space-x-4">
            <button className="p-2 rounded-full hover:bg-white/10 transition-colors relative">
              <Bell size={20} />
              <span className="absolute top-1 right-1 w-2 h-2 bg-spacex-red rounded-full"></span>
            </button>
            <button className="p-2 rounded-full hover:bg-white/10 transition-colors">
              <Search size={20} />
            </button>
          </div>
          
          <div className="md:hidden">
            <button 
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="p-2 rounded-md text-starlight hover:bg-white/10 transition-colors"
            >
              {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>
      
      {/* Mobile menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden glass-panel mx-4 mt-2 p-4 animate-fadeIn">
          <nav className="flex flex-col space-y-4 mb-4">
            <a href="#" className="text-starlight hover:text-white px-3 py-2 hover:bg-white/10 rounded-md transition-colors">Live</a>
            <a href="#" className="text-starlight hover:text-white px-3 py-2 hover:bg-white/10 rounded-md transition-colors">Missions</a>
            <a href="#" className="text-starlight hover:text-white px-3 py-2 hover:bg-white/10 rounded-md transition-colors">Schedule</a>
            <a href="#" className="text-starlight hover:text-white px-3 py-2 hover:bg-white/10 rounded-md transition-colors">News</a>
            <button 
              onClick={() => {
                setShowArchive(true);
                setIsMobileMenuOpen(false);
              }}
              className="text-left text-starlight hover:text-white px-3 py-2 hover:bg-white/10 rounded-md transition-colors"
            >
              Archive
            </button>
          </nav>
          <div className="flex items-center space-x-4">
            <button className="p-2 rounded-full hover:bg-white/10 transition-colors relative">
              <Bell size={20} />
              <span className="absolute top-1 right-1 w-2 h-2 bg-spacex-red rounded-full"></span>
            </button>
            <button className="p-2 rounded-full hover:bg-white/10 transition-colors">
              <Search size={20} />
            </button>
          </div>
        </div>
      )}

      {showArchive && <ArchiveModal onClose={() => setShowArchive(false)} />}
    </header>
  );
};