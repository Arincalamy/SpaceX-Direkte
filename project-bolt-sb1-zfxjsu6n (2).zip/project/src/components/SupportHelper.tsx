import React, { useState } from 'react';
import { Bot, X, MessageSquare, Send, ChevronRight, Mail, Zap, Brain, Shield, Rocket } from 'lucide-react';

interface FAQ {
  question: string;
  answer: string;
  category: 'general' | 'technical' | 'account';
  icon: React.ReactNode;
}

const faqs: FAQ[] = [
  {
    question: "When is the next launch?",
    answer: "The next SpaceX launch is scheduled for May 20, 2025. You can find detailed information in our Launch Schedule section.",
    category: "general",
    icon: <Rocket className="w-4 h-4 text-spacex-red" />
  },
  {
    question: "Why is the live stream not playing?",
    answer: "If the stream isn't playing, check your internet connection or try refreshing the page. During non-launch periods, we show preparation activities or replays.",
    category: "technical",
    icon: <Zap className="w-4 h-4 text-warning" />
  },
  {
    question: "How do I get notifications for launches?",
    answer: "Click the bell icon in the header to set up launch notifications. You can customize which events you want to be notified about.",
    category: "account",
    icon: <Shield className="w-4 h-4 text-spacex-blue" />
  },
  {
    question: "Is this an official SpaceX website?",
    answer: "No, SpaceX Direkte is an independent platform providing 24/7 coverage of SpaceX activities. We are not affiliated with SpaceX.",
    category: "general",
    icon: <Rocket className="w-4 h-4 text-spacex-red" />
  },
  {
    question: "How can I report a technical issue?",
    answer: "Use the contact form below to report any technical issues. Please include as much detail as possible about the problem you're experiencing.",
    category: "technical",
    icon: <Zap className="w-4 h-4 text-warning" />
  },
  {
    question: "Do you offer API access?",
    answer: "Yes, we provide API access for developers. Contact our support team for documentation and access credentials.",
    category: "technical",
    icon: <Brain className="w-4 h-4 text-success" />
  }
];

export const SupportHelper = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [showContact, setShowContact] = useState(false);
  const [message, setMessage] = useState('');
  const [email, setEmail] = useState('');
  const [category, setCategory] = useState('general');
  const [selectedFaq, setSelectedFaq] = useState<FAQ | null>(null);
  const [activeCategory, setActiveCategory] = useState<'all' | 'general' | 'technical' | 'account'>('all');

  const filteredFaqs = faqs.filter(faq => 
    activeCategory === 'all' || faq.category === activeCategory
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission
    setMessage('');
    setEmail('');
    setShowContact(false);
    setIsOpen(false);
  };

  return (
    <>
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 bg-spacex-red p-3 rounded-full shadow-lg hover:bg-spacex-red/90 transition-colors z-50 group"
      >
        <Bot className="w-6 h-6 group-hover:scale-110 transition-transform" />
      </button>

      {isOpen && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-end sm:items-center justify-center p-4 z-50">
          <div className="bg-deep-space/95 w-full max-w-md rounded-xl shadow-xl">
            <div className="p-4 border-b border-white/10">
              <div className="flex justify-between items-center">
                <div className="flex items-center">
                  <div className="bg-spacex-red p-2 rounded-lg">
                    <Bot className="w-6 h-6" />
                  </div>
                  <div className="ml-3">
                    <h3 className="text-xl font-bold">SpaceX Assistant</h3>
                    <p className="text-sm text-starlight/70">Always here to help</p>
                  </div>
                </div>
                <button
                  onClick={() => {
                    setIsOpen(false);
                    setSelectedFaq(null);
                  }}
                  className="text-starlight/70 hover:text-white transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="mt-4 flex items-center">
                <div className="w-2 h-2 bg-success rounded-full animate-pulse"></div>
                <span className="ml-2 text-sm text-success">Online and ready to assist</span>
              </div>
            </div>

            <div className="max-h-[60vh] overflow-y-auto">
              {!showContact && !selectedFaq ? (
                <div className="p-4">
                  <div className="flex space-x-2 mb-4 overflow-x-auto pb-2">
                    <CategoryButton
                      active={activeCategory === 'all'}
                      onClick={() => setActiveCategory('all')}
                      icon={<Brain className="w-4 h-4" />}
                    >
                      All
                    </CategoryButton>
                    <CategoryButton
                      active={activeCategory === 'general'}
                      onClick={() => setActiveCategory('general')}
                      icon={<Rocket className="w-4 h-4" />}
                    >
                      General
                    </CategoryButton>
                    <CategoryButton
                      active={activeCategory === 'technical'}
                      onClick={() => setActiveCategory('technical')}
                      icon={<Zap className="w-4 h-4" />}
                    >
                      Technical
                    </CategoryButton>
                    <CategoryButton
                      active={activeCategory === 'account'}
                      onClick={() => setActiveCategory('account')}
                      icon={<Shield className="w-4 h-4" />}
                    >
                      Account
                    </CategoryButton>
                  </div>

                  <div className="space-y-4">
                    {filteredFaqs.map((faq, index) => (
                      <div
                        key={index}
                        onClick={() => setSelectedFaq(faq)}
                        className="bg-deep-space/50 p-4 rounded-lg hover:bg-deep-space/70 transition-colors cursor-pointer group"
                      >
                        <div className="flex justify-between items-start">
                          <div className="flex items-start space-x-3">
                            <div className="mt-1">{faq.icon}</div>
                            <div>
                              <h4 className="font-medium group-hover:text-white transition-colors">
                                {faq.question}
                              </h4>
                              <span className="inline-block px-2 py-1 rounded-full text-xs bg-deep-space/30 text-starlight/70 mt-2">
                                {faq.category}
                              </span>
                            </div>
                          </div>
                          <ChevronRight className="w-4 h-4 text-starlight/50 group-hover:text-spacex-red transition-colors" />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ) : selectedFaq ? (
                <div className="p-4 space-y-4">
                  <div className="bg-deep-space/50 p-4 rounded-lg">
                    <div className="flex items-center mb-3">
                      {selectedFaq.icon}
                      <h4 className="font-bold text-lg ml-2">{selectedFaq.question}</h4>
                    </div>
                    <p className="text-starlight/90 leading-relaxed">{selectedFaq.answer}</p>
                  </div>
                  <div className="flex justify-between">
                    <button
                      onClick={() => setSelectedFaq(null)}
                      className="button-secondary"
                    >
                      Back to FAQs
                    </button>
                    <button
                      onClick={() => {
                        setSelectedFaq(null);
                        setShowContact(true);
                      }}
                      className="button-primary"
                    >
                      Still Need Help?
                    </button>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="p-4 space-y-4">
                  <div className="bg-deep-space/50 p-4 rounded-lg mb-4">
                    <div className="flex items-center mb-2">
                      <Bot className="w-5 h-5 text-spacex-red mr-2" />
                      <span className="font-medium">Direct Support</span>
                    </div>
                    <p className="text-sm text-starlight/70">
                      I'll make sure your message reaches the right team. Please provide your details below.
                    </p>
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-1">Email</label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-starlight/50" />
                      <input
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full bg-deep-space/50 rounded-lg border border-white/10 p-3 pl-10 text-white placeholder-starlight/50 focus:outline-none focus:border-spacex-red"
                        placeholder="Enter your email"
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-1">Category</label>
                    <select
                      value={category}
                      onChange={(e) => setCategory(e.target.value)}
                      className="w-full bg-deep-space/50 rounded-lg border border-white/10 p-3 text-white focus:outline-none focus:border-spacex-red"
                    >
                      <option value="general">General Inquiry</option>
                      <option value="technical">Technical Support</option>
                      <option value="account">Account Support</option>
                      <option value="other">Other</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-1">Message</label>
                    <textarea
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      className="w-full h-32 bg-deep-space/50 rounded-lg border border-white/10 p-3 text-white placeholder-starlight/50 focus:outline-none focus:border-spacex-red"
                      placeholder="How can I assist you today?"
                      required
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full button-primary flex items-center justify-center"
                  >
                    <Send className="w-4 h-4 mr-2" />
                    Send Message
                  </button>
                </form>
              )}
            </div>

            {!showContact && !selectedFaq && (
              <div className="p-4 border-t border-white/10">
                <button
                  onClick={() => setShowContact(true)}
                  className="w-full button-secondary flex items-center justify-center"
                >
                  <MessageSquare className="w-4 h-4 mr-2" />
                  Need more help? Chat with me
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );
};

interface CategoryButtonProps {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
  icon: React.ReactNode;
}

const CategoryButton: React.FC<CategoryButtonProps> = ({ active, onClick, children, icon }) => (
  <button
    onClick={onClick}
    className={`px-4 py-2 rounded-md whitespace-nowrap transition-colors flex items-center ${
      active ? 'bg-spacex-red text-white' : 'bg-deep-space/50 hover:bg-deep-space/70'
    }`}
  >
    <span className="mr-2">{icon}</span>
    {children}
  </button>
);