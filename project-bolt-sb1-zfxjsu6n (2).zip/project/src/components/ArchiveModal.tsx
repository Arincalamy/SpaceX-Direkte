import React, { useState } from 'react';
import { X, Rocket, Newspaper, Search, Filter, Calendar } from 'lucide-react';

interface ArchiveItem {
  id: number;
  type: 'mission' | 'news';
  title: string;
  date: string;
  description: string;
  image: string;
}

const archiveItems: ArchiveItem[] = [
  {
    id: 1,
    type: 'mission',
    title: 'Crew-6 Mission',
    date: 'March 15, 2025',
    description: 'Successful launch and docking of Crew Dragon spacecraft to the ISS.',
    image: 'https://images.pexels.com/photos/23769/pexels-photo.jpg?auto=compress&cs=tinysrgb&w=1260&h=750'
  },
  {
    id: 2,
    type: 'news',
    title: 'SpaceX Achieves 200th Successful Landing',
    date: 'March 10, 2025',
    description: 'Historic milestone reached with the 200th successful booster landing.',
    image: 'https://images.pexels.com/photos/41006/satellite-dish-receiver-astronomy-space-41006.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750'
  },
  // Add more archive items as needed
];

interface ArchiveModalProps {
  onClose: () => void;
}

export const ArchiveModal: React.FC<ArchiveModalProps> = ({ onClose }) => {
  const [activeTab, setActiveTab] = useState<'all' | 'missions' | 'news'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredItems = archiveItems.filter(item => {
    const matchesTab = activeTab === 'all' || item.type === activeTab.slice(0, -1);
    const matchesSearch = item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         item.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesTab && matchesSearch;
  });

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <div className="bg-deep-space/95 w-full max-w-4xl rounded-xl shadow-xl">
        <div className="p-4 border-b border-white/10 flex justify-between items-center">
          <h3 className="text-xl font-bold flex items-center">
            <Calendar className="w-5 h-5 mr-2 text-spacex-red" />
            SpaceX Archive
          </h3>
          <button
            onClick={onClose}
            className="text-starlight/70 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6">
          <div className="flex flex-col md:flex-row justify-between gap-4 mb-6">
            <div className="flex space-x-2">
              <button
                onClick={() => setActiveTab('all')}
                className={`px-4 py-2 rounded-md transition-colors ${
                  activeTab === 'all' ? 'bg-spacex-red text-white' : 'bg-deep-space/50 hover:bg-deep-space/70'
                }`}
              >
                All
              </button>
              <button
                onClick={() => setActiveTab('missions')}
                className={`px-4 py-2 rounded-md transition-colors ${
                  activeTab === 'missions' ? 'bg-spacex-red text-white' : 'bg-deep-space/50 hover:bg-deep-space/70'
                }`}
              >
                Missions
              </button>
              <button
                onClick={() => setActiveTab('news')}
                className={`px-4 py-2 rounded-md transition-colors ${
                  activeTab === 'news' ? 'bg-spacex-red text-white' : 'bg-deep-space/50 hover:bg-deep-space/70'
                }`}
              >
                News
              </button>
            </div>
            
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-starlight/50" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search archive..."
                className="w-full md:w-64 bg-deep-space/50 rounded-lg border border-white/10 p-2 pl-10 text-white placeholder-starlight/50 focus:outline-none focus:border-spacex-red"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-h-[60vh] overflow-y-auto">
            {filteredItems.map(item => (
              <div
                key={item.id}
                className="bg-deep-space/50 rounded-lg overflow-hidden hover:bg-deep-space/70 transition-colors cursor-pointer group"
              >
                <div className="aspect-video relative">
                  <img
                    src={item.image}
                    alt={item.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-2 left-2">
                    <span className={`px-2 py-1 rounded text-xs font-medium ${
                      item.type === 'mission' ? 'bg-spacex-red' : 'bg-spacex-blue'
                    }`}>
                      {item.type === 'mission' ? 'Mission' : 'News'}
                    </span>
                  </div>
                </div>
                <div className="p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-starlight/70">{item.date}</span>
                    {item.type === 'mission' ? (
                      <Rocket className="w-4 h-4 text-spacex-red" />
                    ) : (
                      <Newspaper className="w-4 h-4 text-spacex-blue" />
                    )}
                  </div>
                  <h4 className="font-bold mb-2">{item.title}</h4>
                  <p className="text-sm text-starlight/70 line-clamp-2">{item.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};