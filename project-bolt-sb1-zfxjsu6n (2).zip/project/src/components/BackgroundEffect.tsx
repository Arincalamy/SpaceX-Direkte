import React, { useEffect, useRef } from 'react';

export const BackgroundEffect = () => {
  const starsRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    if (!starsRef.current) return;
    
    const createStars = () => {
      if (!starsRef.current) return;
      
      // Clear existing stars
      starsRef.current.innerHTML = '';
      
      // Number of stars based on screen size
      const screenWidth = window.innerWidth;
      const screenHeight = window.innerHeight;
      const numberOfStars = Math.floor((screenWidth * screenHeight) / 5000);
      
      for (let i = 0; i < numberOfStars; i++) {
        const star = document.createElement('div');
        star.classList.add('star');
        
        // Random position
        const left = Math.random() * 100;
        const top = Math.random() * 100;
        
        // Random size
        const size = Math.random() * 2 + 1;
        
        // Random animation duration and delay
        const duration = Math.random() * 5 + 3;
        const delay = Math.random() * 5;
        
        star.style.left = `${left}%`;
        star.style.top = `${top}%`;
        star.style.width = `${size}px`;
        star.style.height = `${size}px`;
        star.style.setProperty('--duration', `${duration}s`);
        star.style.setProperty('--delay', `${delay}s`);
        
        starsRef.current.appendChild(star);
      }
    };
    
    createStars();
    
    // Recreate stars on window resize
    window.addEventListener('resize', createStars);
    
    return () => {
      window.removeEventListener('resize', createStars);
    };
  }, []);
  
  return (
    <div className="stars" ref={starsRef}></div>
  );
};