import React from 'react';
import { X, Calendar, Share2, ExternalLink, Clock, Tag } from 'lucide-react';

interface NewsModalProps {
  news: {
    id: number;
    title: string;
    excerpt: string;
    date: string;
    image: string;
    category: 'launch' | 'technology' | 'company' | 'science';
    readTime: string;
  };
  onClose: () => void;
}

export const NewsModal: React.FC<NewsModalProps> = ({ news, onClose }) => {
  const getCategoryColor = (category: NewsModalProps['news']['category']) => {
    switch (category) {
      case 'launch': return 'bg-spacex-red';
      case 'technology': return 'bg-spacex-blue';
      case 'company': return 'bg-success';
      case 'science': return 'bg-warning';
      default: return 'bg-spacex-red';
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <div className="bg-deep-space/95 w-full max-w-3xl rounded-xl shadow-xl">
        <div className="p-4 border-b border-white/10 flex justify-between items-center">
          <div className="flex items-center space-x-4">
            <span className={`px-3 py-1 rounded-full text-sm font-medium ${getCategoryColor(news.category)}`}>
              {news.category.charAt(0).toUpperCase() + news.category.slice(1)}
            </span>
            <div className="flex items-center text-starlight/70">
              <Clock className="w-4 h-4 mr-1" />
              {news.readTime} read
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-starlight/70 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6">
          <div className="aspect-video rounded-lg overflow-hidden mb-6">
            <img 
              src={news.image} 
              alt={news.title}
              className="w-full h-full object-cover"
            />
          </div>

          <h2 className="text-2xl font-bold mb-4">{news.title}</h2>

          <div className="flex items-center space-x-4 mb-6 text-sm text-starlight/70">
            <div className="flex items-center">
              <Calendar className="w-4 h-4 mr-1" />
              {news.date}
            </div>
            <div className="flex items-center">
              <Tag className="w-4 h-4 mr-1" />
              SpaceX News
            </div>
          </div>

          <div className="prose prose-invert max-w-none">
            <p className="text-starlight/90 leading-relaxed mb-4">
              {news.excerpt}
            </p>
            <p className="text-starlight/90 leading-relaxed mb-4">
              This development represents a significant step forward in SpaceX's ongoing mission to revolutionize space travel
              and exploration. The success of this initiative demonstrates the company's commitment to pushing the boundaries
              of what's possible in space technology and human spaceflight.
            </p>
            <p className="text-starlight/90 leading-relaxed">
              As we continue to monitor these developments, the implications for future space missions and technological
              advancement become increasingly clear. This achievement marks another milestone in SpaceX's journey toward
              making space more accessible and advancing our capabilities in space exploration.
            </p>
          </div>

          <div className="mt-8 flex justify-between items-center">
            <div className="flex space-x-4">
              <button className="button-secondary flex items-center">
                <Share2 className="w-4 h-4 mr-2" />
                Share
              </button>
              <button className="button-secondary flex items-center">
                <ExternalLink className="w-4 h-4 mr-2" />
                Full Article
              </button>
            </div>
            <button
              onClick={onClose}
              className="button-primary"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};