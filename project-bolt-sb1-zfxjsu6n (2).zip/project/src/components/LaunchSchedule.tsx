import React, { useState } from 'react';
import { Calendar, ChevronRight } from 'lucide-react';
import { LaunchModal } from './LaunchModal';

interface Launch {
  id: number;
  mission: string;
  vehicle: string;
  date: string;
  location: string;
  status: 'upcoming' | 'delayed' | 'scrubbed';
  crew?: string[];
  payload?: string;
  description?: string;
  targetOrbit?: string;
}

const upcomingLaunches: Launch[] = [
  {
    id: 1,
    mission: 'Starship SN20 Orbital Test',
    vehicle: 'Starship',
    date: '2025-05-20T15:00:00Z',
    location: 'Starbase, TX',
    status: 'upcoming',
    description: 'First orbital test flight of the complete Starship system, including Super Heavy booster and Starship spacecraft.',
    targetOrbit: 'Low Earth Orbit (LEO)',
  },
  {
    id: 2,
    mission: 'Starlink Group 10-1',
    vehicle: 'Falcon 9',
    date: '2025-05-23T18:30:00Z',
    location: 'Cape Canaveral, FL',
    status: 'upcoming',
    payload: '60 Starlink satellites',
    targetOrbit: 'Low Earth Orbit (550 km)',
    description: 'Launch of 60 Starlink satellites to continue building the global internet constellation.'
  },
  {
    id: 3,
    mission: 'CRS-30',
    vehicle: 'Falcon 9',
    date: '2025-06-01T13:45:00Z',
    location: 'Kennedy Space Center, FL',
    status: 'upcoming',
    payload: 'Dragon spacecraft with cargo for ISS',
    description: 'Commercial Resupply Services mission to the International Space Station carrying supplies and scientific experiments.'
  },
  {
    id: 4,
    mission: 'Crew-8 Mission',
    vehicle: 'Falcon 9',
    date: '2025-06-05T20:15:00Z',
    location: 'Kennedy Space Center, FL',
    status: 'delayed',
    crew: [
      'Commander Sarah Johnson',
      'Pilot Michael Chen',
      'Mission Specialist Elena Rodriguez',
      'Mission Specialist David Kim'
    ],
    description: 'Crewed mission to the International Space Station carrying four astronauts for a six-month expedition.'
  },
  {
    id: 5,
    mission: 'PACE',
    vehicle: 'Falcon 9',
    date: '2025-06-12T22:00:00Z',
    location: 'Vandenberg SFB, CA',
    status: 'upcoming',
    payload: 'NASA PACE Earth observation satellite',
    targetOrbit: 'Sun-synchronous orbit (676.5 km)',
    description: 'Launch of NASA\'s Plankton, Aerosol, Cloud, ocean Ecosystem (PACE) satellite for Earth observation.'
  }
];

export const LaunchSchedule = () => {
  const [selectedLaunch, setSelectedLaunch] = useState<Launch | null>(null);

  return (
    <section className="glass-panel p-6">
      <h2 className="section-title">
        <Calendar className="mr-2 text-spacex-red" />
        Upcoming Launches
      </h2>
      
      <div className="space-y-4">
        {upcomingLaunches.map(launch => (
          <LaunchCard 
            key={launch.id} 
            launch={launch} 
            onClick={() => setSelectedLaunch(launch)}
          />
        ))}
      </div>
      
      <div className="mt-6 text-center">
        <button className="button-secondary text-sm w-full">
          View Full Schedule
        </button>
      </div>

      {selectedLaunch && (
        <LaunchModal
          launch={selectedLaunch}
          onClose={() => setSelectedLaunch(null)}
        />
      )}
    </section>
  );
};

interface LaunchCardProps {
  launch: Launch;
  onClick: () => void;
}

const LaunchCard: React.FC<LaunchCardProps> = ({ launch, onClick }) => {
  const getStatusColor = (status: Launch['status']) => {
    switch (status) {
      case 'upcoming': return 'bg-success';
      case 'delayed': return 'bg-warning';
      case 'scrubbed': return 'bg-error';
      default: return 'bg-success';
    }
  };
  
  const getStatusText = (status: Launch['status']) => {
    switch (status) {
      case 'upcoming': return 'On Schedule';
      case 'delayed': return 'Delayed';
      case 'scrubbed': return 'Scrubbed';
      default: return 'On Schedule';
    }
  };

  return (
    <div 
      onClick={onClick}
      className="bg-deep-space/50 rounded-lg p-4 hover:bg-deep-space/70 transition-colors cursor-pointer group"
    >
      <div className="flex justify-between items-start">
        <div>
          <h3 className="font-bold text-white group-hover:text-spacex-red transition-colors">
            {launch.mission}
          </h3>
          <p className="text-sm text-starlight/80">{launch.vehicle}</p>
        </div>
        <ChevronRight size={16} className="text-starlight/50 group-hover:text-spacex-red transition-colors" />
      </div>
      
      <div className="mt-3 flex justify-between items-center">
        <div className="text-sm text-starlight/80">
          <p>{new Date(launch.date).toLocaleDateString('en-US', { 
            month: 'long',
            day: 'numeric',
            year: 'numeric'
          })}</p>
          <p>{launch.location}</p>
        </div>
        
        <div className="flex items-center">
          <div className={`w-2 h-2 rounded-full ${getStatusColor(launch.status)} mr-2`}></div>
          <span className="text-xs">{getStatusText(launch.status)}</span>
        </div>
      </div>

      {(launch.crew || launch.payload) && (
        <div className="mt-2 text-xs text-starlight/60">
          {launch.crew ? `${launch.crew.length} crew members` : launch.payload}
        </div>
      )}
    </div>
  );
};