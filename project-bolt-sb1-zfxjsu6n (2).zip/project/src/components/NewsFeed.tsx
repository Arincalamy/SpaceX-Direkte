import React, { useState } from 'react';
import { Newspaper, ArrowRight, Filter, Calendar } from 'lucide-react';
import { NewsModal } from './NewsModal';

interface NewsItem {
  id: number;
  title: string;
  excerpt: string;
  date: string;
  image: string;
  category: 'launch' | 'technology' | 'company' | 'science';
  readTime: string;
}

const newsItems: NewsItem[] = [
  {
    id: 1,
    title: 'SpaceX Successfully Completes Static Fire Test for Starship SN20',
    excerpt: 'All engines performed nominally during the full-duration test, clearing the way for an orbital launch attempt next month. The test marks a significant milestone in the development of the Starship program.',
    date: '2 hours ago',
    image: 'https://images.pexels.com/photos/41005/rocket-launch-rocket-take-off-soyuz-41005.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750',
    category: 'technology',
    readTime: '3 min'
  },
  {
    id: 2,
    title: 'Crew-7 Mission Returns Safely After 6-Month Stay on ISS',
    excerpt: 'The Dragon capsule splashed down off the coast of Florida with all astronauts in good health after their extended mission. The successful return marks another milestone in SpaceX\'s commercial crew program.',
    date: '8 hours ago',
    image: 'https://images.pexels.com/photos/73910/mars-mars-rover-space-travel-robot-73910.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750',
    category: 'launch',
    readTime: '4 min'
  },
  {
    id: 3,
    title: 'SpaceX and NASA Announce New Commercial Crew Rotation Schedule',
    excerpt: 'The updated manifest includes four additional flights to the International Space Station through 2028, strengthening the partnership between SpaceX and NASA.',
    date: '1 day ago',
    image: 'https://images.pexels.com/photos/6496236/pexels-photo-6496236.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750',
    category: 'company',
    readTime: '5 min'
  },
  {
    id: 4,
    title: 'Starlink Constellation Reaches 5,000 Satellites in Orbit',
    excerpt: 'SpaceX\'s internet constellation continues to grow, providing high-speed internet access to remote areas worldwide. The company celebrates this significant milestone in satellite deployment.',
    date: '2 days ago',
    image: 'https://images.pexels.com/photos/821644/pexels-photo-821644.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750',
    category: 'technology',
    readTime: '3 min'
  },
  {
    id: 5,
    title: 'New Research Collaboration: SpaceX and Universities Study Mars Soil Samples',
    excerpt: 'A groundbreaking partnership between SpaceX and leading universities aims to analyze Martian soil composition for future colonization efforts.',
    date: '3 days ago',
    image: 'https://images.pexels.com/photos/39896/space-station-moon-landing-apollo-15-39896.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750',
    category: 'science',
    readTime: '6 min'
  }
];

export const NewsFeed = () => {
  const [selectedNews, setSelectedNews] = useState<NewsItem | null>(null);
  const [activeCategory, setActiveCategory] = useState<'all' | NewsItem['category']>('all');

  const filteredNews = activeCategory === 'all' 
    ? newsItems 
    : newsItems.filter(item => item.category === activeCategory);

  return (
    <section className="glass-panel p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="section-title mb-0">
          <Newspaper className="mr-2 text-spacex-red" />
          Latest News
        </h2>
        <div className="flex items-center space-x-2">
          <Filter className="w-4 h-4 text-spacex-red" />
          <select 
            value={activeCategory}
            onChange={(e) => setActiveCategory(e.target.value as typeof activeCategory)}
            className="bg-deep-space/50 border border-white/10 rounded-md px-2 py-1 text-sm focus:outline-none focus:border-spacex-red"
          >
            <option value="all">All Categories</option>
            <option value="launch">Launches</option>
            <option value="technology">Technology</option>
            <option value="company">Company</option>
            <option value="science">Science</option>
          </select>
        </div>
      </div>
      
      <div className="grid grid-cols-1 gap-6">
        {filteredNews.map(newsItem => (
          <NewsCard 
            key={newsItem.id} 
            news={newsItem} 
            onClick={() => setSelectedNews(newsItem)}
          />
        ))}
      </div>
      
      <div className="mt-6 flex justify-between items-center">
        <div className="flex items-center text-sm text-starlight/70">
          <Calendar className="w-4 h-4 mr-1" />
          Updated daily
        </div>
        <button className="group flex items-center text-starlight hover:text-white transition-colors">
          <span className="mr-2">View Archive</span>
          <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
        </button>
      </div>

      {selectedNews && (
        <NewsModal
          news={selectedNews}
          onClose={() => setSelectedNews(null)}
        />
      )}
    </section>
  );
};

interface NewsCardProps {
  news: NewsItem;
  onClick: () => void;
}

const NewsCard: React.FC<NewsCardProps> = ({ news, onClick }) => {
  const getCategoryColor = (category: NewsItem['category']) => {
    switch (category) {
      case 'launch': return 'bg-spacex-red';
      case 'technology': return 'bg-spacex-blue';
      case 'company': return 'bg-success';
      case 'science': return 'bg-warning';
      default: return 'bg-spacex-red';
    }
  };

  return (
    <div 
      onClick={onClick}
      className="flex flex-col md:flex-row gap-6 hover:bg-deep-space/30 transition-colors p-4 rounded-lg -mx-2 cursor-pointer group"
    >
      <div className="md:w-1/3 h-48 md:h-36 rounded-lg overflow-hidden">
        <img 
          src={news.image} 
          alt={news.title} 
          className="w-full h-full object-cover transition-transform group-hover:scale-105 duration-500"
        />
      </div>
      <div className="md:w-2/3">
        <div className="flex items-center space-x-3 mb-2">
          <span className={`px-2 py-1 rounded-full text-xs font-medium ${getCategoryColor(news.category)}`}>
            {news.category.charAt(0).toUpperCase() + news.category.slice(1)}
          </span>
          <span className="text-xs text-starlight/60">{news.readTime} read</span>
        </div>
        <h3 className="font-bold text-lg text-white group-hover:text-spacex-red transition-colors">
          {news.title}
        </h3>
        <p className="text-sm text-starlight/80 mt-2 line-clamp-2">{news.excerpt}</p>
        <p className="text-xs text-starlight/60 mt-3">{news.date}</p>
      </div>
    </div>
  );
};