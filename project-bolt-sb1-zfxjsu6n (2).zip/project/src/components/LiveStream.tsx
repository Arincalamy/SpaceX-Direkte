import React, { useState } from 'react';
import { Play, Volume2, ExternalLink, Share2, Clock, Grid2X2, Maximize2, Radio, Youtube } from 'lucide-react';
import { CountdownTimer } from './CountdownTimer';

interface CameraView {
  id: string;
  title: string;
  youtubeId: string;
  thumbnail: string;
  status: 'live' | 'offline';
  viewers: number;
}

const cameraViews: CameraView[] = [
  {
    id: 'main',
    title: 'Launch Pad Overview',
    youtubeId: 'ATP6_fFLFp0',
    thumbnail: 'https://images.pexels.com/photos/23769/pexels-photo.jpg?auto=compress&cs=tinysrgb&w=1260&h=750',
    status: 'live',
    viewers: 24826
  },
  {
    id: 'tower',
    title: 'Launch Tower Cam',
    youtubeId: 'ATP6_fFLFp0',
    thumbnail: 'https://images.pexels.com/photos/2159/flight-sky-earth-space.jpg?auto=compress&cs=tinysrgb&w=1260&h=750',
    status: 'live',
    viewers: 15341
  },
  {
    id: 'tracking',
    title: 'Tracking Cam',
    youtubeId: 'ATP6_fFLFp0',
    thumbnail: 'https://images.pexels.com/photos/39698/space-shuttle-lift-off-liftoff-nasa-39698.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750',
    status: 'live',
    viewers: 12789
  },
  {
    id: 'aerial',
    title: 'Aerial View',
    youtubeId: 'ATP6_fFLFp0',
    thumbnail: 'https://images.pexels.com/photos/41006/satellite-dish-receiver-astronomy-space-41006.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750',
    status: 'live',
    viewers: 18452
  }
];

export const LiveStream = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [activeView, setActiveView] = useState('main');
  const [isGridView, setIsGridView] = useState(false);
  const [isTheaterMode, setIsTheaterMode] = useState(false);
  const nextLaunchTime = new Date(Date.now() + 4 * 24 * 60 * 60 * 1000);

  const handlePlayClick = () => {
    setIsPlaying(true);
  };

  const formatViewers = (count: number) => {
    return new Intl.NumberFormat('en-US').format(count);
  };

  const renderYouTubeEmbed = (youtubeId: string) => (
    <iframe
      src={`https://www.youtube.com/embed/${youtubeId}?autoplay=1&mute=1&rel=0&modestbranding=1`}
      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
      allowFullScreen
      className="w-full h-full absolute inset-0"
    />
  );

  return (
    <section className={`mt-4 ${isTheaterMode ? 'fixed inset-0 z-50 bg-black p-4' : ''}`}>
      <div className="flex justify-between items-center mb-4">
        <div className="flex items-center">
          <div className="w-3 h-3 bg-spacex-red rounded-full animate-pulse mr-2"></div>
          <h2 className="font-bold text-xl">LIVE: Starbase 24/7 Coverage</h2>
          <span className="ml-4 text-sm text-starlight/70">
            <Radio size={14} className="inline mr-1" />
            {formatViewers(cameraViews.reduce((acc, view) => acc + view.viewers, 0))} watching
          </span>
        </div>
        <div className="hidden md:flex items-center space-x-4">
          <button 
            onClick={() => setIsGridView(!isGridView)}
            className="text-starlight/80 hover:text-white flex items-center"
          >
            <Grid2X2 size={16} className="mr-1" />
            <span>{isGridView ? 'Single View' : 'Grid View'}</span>
          </button>
          <button 
            onClick={() => {
              const url = `https://www.youtube.com/watch?v=${cameraViews.find(v => v.id === activeView)?.youtubeId}`;
              navigator.clipboard.writeText(url);
            }}
            className="text-starlight/80 hover:text-white flex items-center"
          >
            <Share2 size={16} className="mr-1" />
            <span>Share</span>
          </button>
          <button 
            onClick={() => setIsTheaterMode(!isTheaterMode)}
            className="text-starlight/80 hover:text-white flex items-center"
          >
            <Maximize2 size={16} className="mr-1" />
            <span>Theater Mode</span>
          </button>
        </div>
      </div>

      <div className={`grid ${isGridView ? 'grid-cols-2 gap-4' : 'grid-cols-1'}`}>
        {(isGridView ? cameraViews : [cameraViews.find(view => view.id === activeView)!]).map(view => (
          <div key={view.id} className="relative aspect-video rounded-xl overflow-hidden bg-black/40 glass-panel group mb-4">
            {!isPlaying ? (
              <>
                <div className="absolute inset-0 flex items-center justify-center z-10">
                  <button 
                    onClick={handlePlayClick}
                    className="w-16 h-16 md:w-20 md:h-20 bg-spacex-red/90 rounded-full flex items-center justify-center transition-transform hover:scale-110 group"
                  >
                    <Play size={30} className="fill-white text-white ml-1" />
                  </button>
                </div>
                <div className="absolute top-4 left-4 flex items-center space-x-2">
                  <Youtube size={24} className="text-spacex-red" />
                  <span className="bg-spacex-red px-2 py-1 rounded text-sm font-medium">
                    {view.title}
                  </span>
                </div>
                <img 
                  src={view.thumbnail}
                  alt={view.title}
                  className="w-full h-full object-cover"
                />
              </>
            ) : (
              renderYouTubeEmbed(view.youtubeId)
            )}

            <div className={`absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/80 to-transparent ${
              isPlaying ? 'opacity-0 group-hover:opacity-100 transition-opacity' : ''
            }`}>
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <div className="w-2 h-2 bg-spacex-red rounded-full animate-pulse mr-2"></div>
                  <span className="text-sm font-medium">LIVE</span>
                </div>
                <span className="text-sm">{formatViewers(view.viewers)} watching</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {!isGridView && (
        <div className="grid grid-cols-4 gap-4 mt-4">
          {cameraViews.map(view => (
            <button
              key={view.id}
              onClick={() => setActiveView(view.id)}
              className={`relative aspect-video rounded-lg overflow-hidden transition-all ${
                activeView === view.id ? 'ring-2 ring-spacex-red' : 'opacity-70 hover:opacity-100'
              }`}
            >
              <img 
                src={view.thumbnail}
                alt={view.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent">
                <div className="absolute bottom-2 left-2 right-2">
                  <p className="text-sm font-medium truncate">{view.title}</p>
                  <p className="text-xs text-starlight/70">{formatViewers(view.viewers)} watching</p>
                </div>
              </div>
              {view.status === 'live' && (
                <div className="absolute top-2 left-2 flex items-center">
                  <div className="w-2 h-2 bg-spacex-red rounded-full animate-pulse mr-1"></div>
                  <span className="text-xs font-medium">LIVE</span>
                </div>
              )}
            </button>
          ))}
        </div>
      )}

      {!isTheaterMode && (
        <div className="mt-6 glass-panel p-4">
          <div className="flex items-center text-lg font-semibold">
            <Clock size={20} className="mr-2 text-spacex-red" />
            <span>Next launch in:</span>
          </div>
          <CountdownTimer targetDate={nextLaunchTime} />
        </div>
      )}
    </section>
  );
};