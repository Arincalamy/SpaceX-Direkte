import React from 'react';
import { Rocket, Twitter, Youtube, Instagram, Facebook } from 'lucide-react';

export const Footer = () => {
  return (
    <footer className="bg-deep-space/80 backdrop-blur-md border-t border-white/10 mt-16">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center">
              <Rocket className="h-8 w-8 text-spacex-red" />
              <span className="ml-2 text-xl font-bold">SpaceX Direkte</span>
            </div>
            <p className="mt-4 text-starlight/70 text-sm">
              24/7 coverage of SpaceX missions, launches, and space exploration news. Your front-row seat to the future of space travel.
            </p>
            <div className="flex space-x-4 mt-6">
              <SocialLink icon={<Twitter size={18} />} />
              <SocialLink icon={<Youtube size={18} />} />
              <SocialLink icon={<Instagram size={18} />} />
              <SocialLink icon={<Facebook size={18} />} />
            </div>
          </div>
          
          <div>
            <h3 className="font-bold text-lg mb-4">Watch</h3>
            <ul className="space-y-2">
              <FooterLink text="Live Stream" />
              <FooterLink text="Recent Launches" />
              <FooterLink text="Upcoming Events" />
              <FooterLink text="Mission Archive" />
              <FooterLink text="SpaceX Official" />
            </ul>
          </div>
          
          <div>
            <h3 className="font-bold text-lg mb-4">Explore</h3>
            <ul className="space-y-2">
              <FooterLink text="Rockets" />
              <FooterLink text="Dragon" />
              <FooterLink text="Starship" />
              <FooterLink text="Starlink" />
              <FooterLink text="Human Spaceflight" />
            </ul>
          </div>
          
          <div>
            <h3 className="font-bold text-lg mb-4">About</h3>
            <ul className="space-y-2">
              <FooterLink text="About Us" />
              <FooterLink text="Contact" />
              <FooterLink text="Privacy Policy" />
              <FooterLink text="Terms of Service" />
              <FooterLink text="Subscribe" />
            </ul>
          </div>
        </div>
        
        <div className="border-t border-white/10 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-starlight/60 text-sm">
            © 2025 SpaceX Direkte. Not affiliated with SpaceX. All rights reserved. /@SpaceX Direkte CEO Arin Calamy
          </p>
          <p className="text-starlight/60 text-sm mt-4 md:mt-0">
            Space exploration coverage for enthusiasts, by enthusiasts.
          </p>
        </div>
      </div>
    </footer>
  );
};

const FooterLink: React.FC<{ text: string }> = ({ text }) => (
  <li>
    <a href="#" className="text-starlight/70 hover:text-white transition-colors">
      {text}
    </a>
  </li>
);

const SocialLink: React.FC<{ icon: React.ReactNode }> = ({ icon }) => (
  <a 
    href="#" 
    className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center hover:bg-spacex-red transition-colors"
  >
    {icon}
  </a>
);