import React from 'react';
import { X, Rocket, Calendar, MapPin, AlertCircle, Clock, Users, Satellite } from 'lucide-react';
import { CountdownTimer } from './CountdownTimer';

interface LaunchModalProps {
  launch: {
    id: number;
    mission: string;
    vehicle: string;
    date: string;
    location: string;
    status: 'upcoming' | 'delayed' | 'scrubbed';
    crew?: string[];
    payload?: string;
    description?: string;
    targetOrbit?: string;
  };
  onClose: () => void;
}

export const LaunchModal: React.FC<LaunchModalProps> = ({ launch, onClose }) => {
  const getStatusColor = (status: LaunchModalProps['launch']['status']) => {
    switch (status) {
      case 'upcoming': return 'bg-success';
      case 'delayed': return 'bg-warning';
      case 'scrubbed': return 'bg-error';
      default: return 'bg-success';
    }
  };

  const getStatusText = (status: LaunchModalProps['launch']['status']) => {
    switch (status) {
      case 'upcoming': return 'On Schedule';
      case 'delayed': return 'Delayed';
      case 'scrubbed': return 'Scrubbed';
      default: return 'On Schedule';
    }
  };

  const launchDate = new Date(launch.date);

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <div className="bg-deep-space/95 w-full max-w-3xl rounded-xl shadow-xl">
        <div className="p-4 border-b border-white/10 flex justify-between items-center">
          <h3 className="text-xl font-bold flex items-center">
            <Rocket className="w-5 h-5 mr-2 text-spacex-red" />
            Mission Details
          </h3>
          <button
            onClick={onClose}
            className="text-starlight/70 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6">
          <div className="flex justify-between items-start mb-6">
            <div>
              <h2 className="text-2xl font-bold">{launch.mission}</h2>
              <p className="text-starlight/70 mt-1">{launch.vehicle}</p>
            </div>
            <div className={`px-3 py-1 rounded-full flex items-center ${getStatusColor(launch.status)}`}>
              <div className="w-2 h-2 rounded-full bg-white mr-2"></div>
              <span className="text-sm font-medium">{getStatusText(launch.status)}</span>
            </div>
          </div>

          <div className="bg-deep-space/50 rounded-lg p-6 mb-6">
            <h4 className="font-bold mb-4">Launch Timeline</h4>
            <CountdownTimer targetDate={launchDate} />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div className="bg-deep-space/50 p-4 rounded-lg">
              <div className="flex items-center mb-3">
                <Calendar className="w-5 h-5 mr-2 text-spacex-red" />
                <h4 className="font-bold">Launch Window</h4>
              </div>
              <p className="text-starlight/90">{launch.date}</p>
            </div>

            <div className="bg-deep-space/50 p-4 rounded-lg">
              <div className="flex items-center mb-3">
                <MapPin className="w-5 h-5 mr-2 text-spacex-red" />
                <h4 className="font-bold">Launch Site</h4>
              </div>
              <p className="text-starlight/90">{launch.location}</p>
            </div>

            {launch.targetOrbit && (
              <div className="bg-deep-space/50 p-4 rounded-lg">
                <div className="flex items-center mb-3">
                  <Satellite className="w-5 h-5 mr-2 text-spacex-red" />
                  <h4 className="font-bold">Target Orbit</h4>
                </div>
                <p className="text-starlight/90">{launch.targetOrbit}</p>
              </div>
            )}

            {launch.crew && launch.crew.length > 0 && (
              <div className="bg-deep-space/50 p-4 rounded-lg">
                <div className="flex items-center mb-3">
                  <Users className="w-5 h-5 mr-2 text-spacex-red" />
                  <h4 className="font-bold">Crew</h4>
                </div>
                <ul className="space-y-1">
                  {launch.crew.map((member, index) => (
                    <li key={index} className="text-starlight/90">{member}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>

          <div className="space-y-4">
            <h4 className="font-bold">Mission Description</h4>
            <p className="text-starlight/90 leading-relaxed">
              {launch.description || `This mission represents another step in SpaceX's ongoing efforts to advance space technology
              and maintain a regular launch cadence. The mission includes various objectives and technological
              demonstrations that will help pave the way for future space exploration.`}
            </p>

            {launch.payload && (
              <div className="mt-4">
                <h4 className="font-bold mb-2">Payload</h4>
                <p className="text-starlight/90">{launch.payload}</p>
              </div>
            )}

            <div className="mt-6 flex justify-end space-x-4">
              <button
                onClick={onClose}
                className="button-secondary"
              >
                Close
              </button>
              <button className="button-primary flex items-center">
                <Clock className="w-4 h-4 mr-2" />
                Set Reminder
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};