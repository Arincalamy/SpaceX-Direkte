import React from 'react';
import { Header } from './components/Header';
import { LiveStream } from './components/LiveStream';
import { MissionInfo } from './components/MissionInfo';
import { LaunchSchedule } from './components/LaunchSchedule';
import { NewsFeed } from './components/NewsFeed';
import { Footer } from './components/Footer';
import { BackgroundEffect } from './components/BackgroundEffect';
import { SupportHelper } from './components/SupportHelper';

function App() {
  return (
    <div className="min-h-screen bg-deep-space text-starlight relative overflow-hidden">
      <BackgroundEffect />
      <div className="relative z-10">
        <Header />
        <main className="container mx-auto px-4 pb-16">
          <LiveStream />
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-8">
            <div className="lg:col-span-2">
              <MissionInfo />
              <NewsFeed />
            </div>
            <div>
              <LaunchSchedule />
            </div>
          </div>
        </main>
        <Footer />
        <SupportHelper />
      </div>
    </div>
  );
}

export default App;